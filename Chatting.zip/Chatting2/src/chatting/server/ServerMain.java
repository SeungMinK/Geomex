package chatting.server;

public class ServerMain {

    public static void main(String[] args) {
         new Server();
        System.out.println("서버가 종료되었습니다.");
    }
}
