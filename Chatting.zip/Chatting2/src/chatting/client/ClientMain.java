package chatting.client;

public class ClientMain {

    public static void main(String[] args) {

        // 클라이언트 객체 생성, 생성자 호출
        new Client();
       

    }
}
