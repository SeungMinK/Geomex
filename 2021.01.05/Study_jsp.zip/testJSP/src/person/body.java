package person;

public class body{

	//�񸸷� ����
	public float ObesityRate(int i, int j) {
		
		return (float)i/(j*2);
	}
	
}
