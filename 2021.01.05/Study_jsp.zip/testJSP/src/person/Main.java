package person;

public class Main {

	public static void main(String[] args) {
		
		intern SeungMin = new intern(170, 64, 25, "�¹�","�Ѹ����б�");
		intern Junhyuk = new intern(177, 80, 25, "����","�Ѹ����б�");
		
		
		SeungMin.show();
		System.out.println();
		Junhyuk.show();
		System.out.println();
		
		SeungMin.think();
		SeungMin.cooking();
		SeungMin.run();
		
		System.out.println();
		float ObesityRate=SeungMin.internBody.ObesityRate(SeungMin.getWeight(),SeungMin.getHeight());
		float longJump = SeungMin.internLeg.longJump(SeungMin.getHeight(),SeungMin.getWeight());
		System.out.println("�񸸷� : "+ObesityRate);
		System.out.println("���� �ָ� �ٱ� : "+longJump);
	}
}
